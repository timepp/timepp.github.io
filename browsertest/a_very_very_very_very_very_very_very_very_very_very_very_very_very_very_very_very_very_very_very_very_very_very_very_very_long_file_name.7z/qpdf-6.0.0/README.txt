This file is README-windows-install.txt in the source distribution and
README.txt in the Windows binary distribution.

QPDF is completely relocatable.  To use qpdf.exe or the qpdf DLL, just
have the bin directory in your path.  To compile with qpdf, just add
the lib directory to your library path and the include directory to
your include path.  Detailed documentation may be found in the doc
directory.

Enjoy!
